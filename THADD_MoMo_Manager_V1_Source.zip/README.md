# THADD MoMo Manager — V1

Flutter Android starter app for THADD MOBILE MONEY VENTURES.

## Features
- Record MTN and Telecel transactions
- Transaction amount, commission, related expense, reference, staff and date/time
- Dashboard with today's totals and estimated net profit
- Monthly reports
- Manually maintained cash, MTN float and Telecel float balances
- Local SQLite storage on the Android device

## Important limitations
- This is a starter source project, not a compiled or tested APK.
- It records business activity; it does not send or receive actual MTN/Telecel money.
- Float balances are manual and do not automatically change after transactions.
- Data is stored locally. There is no cloud backup, login, or export feature in V1.
- Never store customer PINs, OTPs, passwords, or sensitive identity details.

## Build instructions
1. Install Flutter and Android SDK on a computer or cloud development environment.
2. Extract this ZIP and open the project folder.
3. Run `flutter pub get`.
4. Run `flutter analyze` and fix any reported issues.
5. Connect an Android device or start an emulator and run `flutter run`.
6. To build a debug APK, run `flutter build apk --debug`.
7. The APK should be created at `build/app/outputs/flutter-apk/app-debug.apk`.

Because development is being done from an Android phone, you can use a browser-based cloud IDE that supports Flutter, or ask a trusted computer user to perform the build. Review permissions and test with sample data before using real business records.
