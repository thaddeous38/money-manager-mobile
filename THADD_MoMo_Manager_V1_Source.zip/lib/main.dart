import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:intl/intl.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Store.instance.init();
  runApp(const ThaddApp());
}

final money = NumberFormat.currency(locale: 'en_GH', symbol: 'GH₵', decimalDigits: 2);

class Txn {
  final int? id;
  final String network, type, reference, staff;
  final double amount, commission, expense;
  final DateTime date;
  Txn({this.id, required this.network, required this.type, required this.reference,
    required this.staff, required this.amount, required this.commission,
    required this.expense, required this.date});
  Map<String, Object?> toMap() => {
    'network': network, 'type': type, 'reference': reference, 'staff': staff,
    'amount': amount, 'commission': commission, 'expense': expense,
    'date': date.toIso8601String()
  };
  factory Txn.fromMap(Map<String, Object?> m) => Txn(
    id: m['id'] as int, network: m['network'] as String, type: m['type'] as String,
    reference: m['reference'] as String, staff: m['staff'] as String,
    amount: (m['amount'] as num).toDouble(), commission: (m['commission'] as num).toDouble(),
    expense: (m['expense'] as num).toDouble(), date: DateTime.parse(m['date'] as String));
}

class Store {
  Store._();
  static final instance = Store._();
  late Database db;
  Future<void> init() async {
    final path = p.join(await getDatabasesPath(), 'thadd_momo_v1.db');
    db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''CREATE TABLE transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT, network TEXT NOT NULL, type TEXT NOT NULL,
        reference TEXT NOT NULL, staff TEXT NOT NULL, amount REAL NOT NULL,
        commission REAL NOT NULL, expense REAL NOT NULL, date TEXT NOT NULL)''');
      await db.execute('''CREATE TABLE balances(id INTEGER PRIMARY KEY, cash REAL NOT NULL, mtn REAL NOT NULL, telecel REAL NOT NULL)''');
      await db.insert('balances', {'id': 1, 'cash': 0, 'mtn': 0, 'telecel': 0});
    });
  }
  Future<List<Txn>> all() async {
    final rows = await db.query('transactions', orderBy: 'date DESC');
    return rows.map(Txn.fromMap).toList();
  }
  Future<void> add(Txn t) async => db.insert('transactions', t.toMap());
  Future<Map<String, double>> balances() async {
    final r = (await db.query('balances', where: 'id=1')).first;
    return {'cash': (r['cash'] as num).toDouble(), 'mtn': (r['mtn'] as num).toDouble(), 'telecel': (r['telecel'] as num).toDouble()};
  }
  Future<void> saveBalances(double cash, double mtn, double telecel) async {
    await db.update('balances', {'cash': cash, 'mtn': mtn, 'telecel': telecel}, where: 'id=1');
  }
}

class ThaddApp extends StatelessWidget {
  const ThaddApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'THADD MoMo Manager',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff087443)), useMaterial3: true),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab = 0;
  List<Txn> txns = [];
  Map<String,double> bal = {'cash':0,'mtn':0,'telecel':0};
  @override void initState() { super.initState(); refresh(); }
  Future<void> refresh() async {
    final t = await Store.instance.all(); final b = await Store.instance.balances();
    if (mounted) setState(() { txns=t; bal=b; });
  }
  List<Txn> get today => txns.where((t) => t.date.year==DateTime.now().year && t.date.month==DateTime.now().month && t.date.day==DateTime.now().day).toList();
  double sum(Iterable<Txn> xs, double Function(Txn) f) => xs.fold(0, (s,t)=>s+f(t));
  @override Widget build(BuildContext context) {
    final pages = [
      dashboard(),
      transactionList(),
      const BalancePage(),
      reports(),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('THADD MOBILE MONEY VENTURES'), backgroundColor: Theme.of(context).colorScheme.primary, foregroundColor: Colors.white),
      body: pages[tab],
      floatingActionButton: tab==1 ? FloatingActionButton.extended(onPressed: () async {
        await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddTxnPage()));
        await refresh();
      }, icon: const Icon(Icons.add), label: const Text('New transaction')) : null,
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) async {
        setState(()=>tab=v); await refresh();
      }, destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Transactions'),
        NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Cash & float'),
        NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Reports'),
      ]),
    );
  }
  Widget metric(String label, String value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
    CircleAvatar(child: Icon(icon)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: Colors.black54)), const SizedBox(height: 4), Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold))]))
  ])));
  Widget dashboard() => RefreshIndicator(onRefresh: refresh, child: ListView(padding: const EdgeInsets.all(12), children: [
    Text(DateFormat('EEEE, d MMMM yyyy').format(DateTime.now()), style: Theme.of(context).textTheme.titleMedium),
    metric("Today's transactions", '${today.length}', Icons.receipt_long),
    metric("Today's transaction value", money.format(sum(today, (t)=>t.amount)), Icons.payments),
    metric("Today's commission", money.format(sum(today, (t)=>t.commission)), Icons.trending_up),
    metric("Today's net profit estimate", money.format(sum(today, (t)=>t.commission-t.expense)), Icons.savings),
    const Padding(padding: EdgeInsets.all(8), child: Text('Current balances', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
    metric('Cash on hand', money.format(bal['cash']), Icons.money),
    metric('MTN electronic float', money.format(bal['mtn']), Icons.phone_android),
    metric('Telecel electronic float', money.format(bal['telecel']), Icons.phone_android),
    const Padding(padding: EdgeInsets.all(8), child: Text('Reminder: enter the actual commission you receive. This app records transactions; it does not move money through MTN or Telecel.', style: TextStyle(color: Colors.black54))),
  ]));
  Widget transactionList() => txns.isEmpty ? const Center(child: Text('No transactions yet.\nTap New transaction to record one.', textAlign: TextAlign.center)) : ListView.builder(itemCount: txns.length, itemBuilder: (_,i) {
    final t=txns[i]; return ListTile(leading: CircleAvatar(child: Icon(t.type=='Cash-in'?Icons.call_received:Icons.call_made)), title: Text('${t.network} · ${t.type}'), subtitle: Text('${DateFormat('d MMM, HH:mm').format(t.date)} · ${t.staff}'), trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [Text(money.format(t.amount), style: const TextStyle(fontWeight: FontWeight.bold)), Text('Comm. ${money.format(t.commission)}', style: const TextStyle(fontSize: 11))]));
  });
  Widget reports() {
    final month=txns.where((t)=>t.date.year==DateTime.now().year&&t.date.month==DateTime.now().month).toList();
    return ListView(padding: const EdgeInsets.all(12), children: [
      Text(DateFormat('MMMM yyyy').format(DateTime.now()), style: Theme.of(context).textTheme.headlineSmall),
      metric('Month transaction count', '${month.length}', Icons.numbers),
      metric('Month transaction value', money.format(sum(month,(t)=>t.amount)), Icons.payments),
      metric('Month commission', money.format(sum(month,(t)=>t.commission)), Icons.trending_up),
      metric('Month recorded expenses', money.format(sum(month,(t)=>t.expense)), Icons.money_off),
      metric('Month net profit estimate', money.format(sum(month,(t)=>t.commission-t.expense)), Icons.savings),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Profit estimate = recorded commission − recorded expenses. Add all business-related expenses for a more accurate figure.'))),
    ]);
  }
}

class AddTxnPage extends StatefulWidget { const AddTxnPage({super.key}); @override State<AddTxnPage> createState()=>_AddTxnPageState(); }
class _AddTxnPageState extends State<AddTxnPage> {
  final form=GlobalKey<FormState>(); final amount=TextEditingController(), commission=TextEditingController(), expense=TextEditingController(), ref=TextEditingController(), staff=TextEditingController(text:'Owner');
  String network='MTN', type='Cash-in';
  @override void dispose(){amount.dispose();commission.dispose();expense.dispose();ref.dispose();staff.dispose();super.dispose();}
  String? requiredText(String? v)=>v==null||v.trim().isEmpty?'Required':null;
  double number(TextEditingController c)=>double.tryParse(c.text.trim())??0;
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Record transaction')), body:Form(key:form, child:ListView(padding:const EdgeInsets.all(16), children:[
    DropdownButtonFormField(value:network, decoration:const InputDecoration(labelText:'Network', border:OutlineInputBorder()), items:['MTN','Telecel'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(), onChanged:(v)=>setState(()=>network=v!)),
    const SizedBox(height:12),
    DropdownButtonFormField(value:type, decoration:const InputDecoration(labelText:'Transaction type', border:OutlineInputBorder()), items:['Cash-in','Cash-out','Transfer','Airtime/Data','Bill payment','Other'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(), onChanged:(v)=>setState(()=>type=v!)),
    const SizedBox(height:12),
    TextFormField(controller:amount, validator:requiredText, keyboardType:const TextInputType.numberWithOptions(decimal:true), decoration:const InputDecoration(labelText:'Transaction amount (GH₵)', border:OutlineInputBorder())),
    const SizedBox(height:12),
    TextFormField(controller:commission, validator:requiredText, keyboardType:const TextInputType.numberWithOptions(decimal:true), decoration:const InputDecoration(labelText:'Commission received (GH₵)', border:OutlineInputBorder())),
    const SizedBox(height:12),
    TextFormField(controller:expense, keyboardType:const TextInputType.numberWithOptions(decimal:true), decoration:const InputDecoration(labelText:'Related expense (GH₵)', border:OutlineInputBorder(), helperText:'Leave blank if none')),
    const SizedBox(height:12),
    TextFormField(controller:ref, decoration:const InputDecoration(labelText:'Reference (optional; no PIN/OTP)', border:OutlineInputBorder())),
    const SizedBox(height:12),
    TextFormField(controller:staff, validator:requiredText, decoration:const InputDecoration(labelText:'Staff / operator', border:OutlineInputBorder())),
    const SizedBox(height:20),
    FilledButton.icon(onPressed:() async {
      if(!form.currentState!.validate()) return;
      if(number(amount)<=0||number(commission)<0||number(expense)<0){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter a positive amount and non-negative commission/expense.')));return;}
      await Store.instance.add(Txn(network:network,type:type,reference:ref.text.trim(),staff:staff.text.trim(),amount:number(amount),commission:number(commission),expense:number(expense),date:DateTime.now()));
      if(context.mounted) Navigator.pop(context);
    }, icon:const Icon(Icons.save), label:const Text('Save transaction')),
  ])));
}

class BalancePage extends StatefulWidget { const BalancePage({super.key}); @override State<BalancePage> createState()=>_BalancePageState(); }
class _BalancePageState extends State<BalancePage> {
  final cash=TextEditingController(), mtn=TextEditingController(), telecel=TextEditingController();
  bool loaded=false;
  @override void dispose(){cash.dispose();mtn.dispose();telecel.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>FutureBuilder<Map<String,double>>(future:Store.instance.balances(), builder:(context,snap){
    if(snap.hasData&&!loaded){cash.text=snap.data!['cash']!.toStringAsFixed(2);mtn.text=snap.data!['mtn']!.toStringAsFixed(2);telecel.text=snap.data!['telecel']!.toStringAsFixed(2);loaded=true;}
    if(!snap.hasData)return const Center(child:CircularProgressIndicator());
    Widget field(String label,TextEditingController c)=>Padding(padding:const EdgeInsets.only(bottom:14),child:TextField(controller:c,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:InputDecoration(labelText:label,border:const OutlineInputBorder(),prefixText:'GH₵ ')));
    return ListView(padding:const EdgeInsets.all(16),children:[
      const Text('Enter your current balances manually. These figures do not automatically change when you record a transaction.',style:TextStyle(color:Colors.black54)),
      const SizedBox(height:18),field('Cash on hand',cash),field('MTN electronic float',mtn),field('Telecel electronic float',telecel),
      FilledButton.icon(onPressed:() async {double val(TextEditingController c)=>double.tryParse(c.text)??0;await Store.instance.saveBalances(val(cash),val(mtn),val(telecel));if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Balances saved')));},icon:const Icon(Icons.save),label:const Text('Save balances')),
    ]);
  });
}
